//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Industry - Jewelry Material Cost Calculator
var jewelryName = "3 tone earrings";
var wire1 = 16; 
var wire1cost = .32; 
var wire2 = 6;
var wire2cost = 6.09;
var wire3 = 4; 
var wire3cost = 6.12;
var matCost = 12.04;
var totalPieces = 3; 
var total1 = (wire1*wire1cost)+(wire2*wire2cost)+(wire3*wire3cost)+matCost;
var totalCost = total1 * totalPieces;

console.log(totalCost)