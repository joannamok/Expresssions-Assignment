//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Stone Lot Calculator 

var stoneLot = [164] + [86] + [72] + [34] + [23] + [64] + [85];  //each is an amount of stones in a variety of lots or inventory.

var total = stoneLot[0] + stoneLot[4] + stoneLot[6]; // adds lots together 

console.log("You will receive a total of"+" "+(total)+" "+"stones with your selected lots. ");