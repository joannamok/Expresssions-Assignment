//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Personal - School Lunch Caluculator

var numKids = 3;     //How many Kids will be purchasing school lunches? 
var costLunch = 2.50;    //How much is lunch at school? 
var schoolDays = 180; //How many Days in a School Year?
var total = numKids * costLunch * schoolDays; //total cost for year

console.log("It will cost"+" "+"$"+total+" "+"for"+" "+numKids+" "+"kid/kids to buy lunches for a full"+" "+schoolDays+" "+"day school year.");
