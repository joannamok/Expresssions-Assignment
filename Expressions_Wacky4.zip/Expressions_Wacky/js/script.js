//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Copper Wire Wrap Jewelry Material Cost Calculator

var name = "pendant"

var wire16 = 0 * .02; //How many inches of 16 gauge wire? 

var wire20 = 0 * .02; //How many inches of 20 gauge wire? 

var wire22 = 32 * .01; //How many inches of 22 gauge wire? 

var wire24 = 10 * .001; //How many inches of 24 gauge wire? 

var earwire = 0 * 1.8; //Add Sterling Earwires? 

var materials = 16.99; //Material Costs such as beads or crystals

var numDesigns = 1; //How many pieces are you making? 

var totalCost = (wire16 + wire20 + wire22 + wire24 + earwire + materials)*numDesigns;

console.log("Your total material cost to make"+" "+numDesigns+" "+"of your copper"+" "+name+" "+"design will be"+" "+"$"+totalCost+".");