//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Personal - School Lunch Caluculator

var numKids = 2;     //How many Kids will be purchasing school lunches? 
var costLunch = 1.75;    //How much is lunch at school? 
var schoolDays = 180; //How many Days in a School Year?
var total = numKids * costLunch * schoolDays; //total cost for year

console.log("It will cost"+" "+"$"+total+" "+"for"+" "+numKids+" "+"kid/kids to buy lunches for a full"+" "+schoolDays+" "+"day school year.");
