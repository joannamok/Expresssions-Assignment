//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Personal - School Lunch Caluculator

var numKids = 2;     
var costLunch = 1.75;    
var schoolDays = 180; 
var total = numKids * costLunch * schoolDays; 

console.log("It will cost"+"$"+total+"for"+numKids+"kid/kids to buy lunches for a full"+schoolDays+"day school year.");
