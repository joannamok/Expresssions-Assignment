//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Industry - Jewelry Material Cost Calculator
var jewelryName = "prong ring";
var wire1 = 44.5; //How many inches Wire 1? 
var wire1cost = .32; //How much money is Wire 1 per inch? 
var wire2 = 0;//How many inch Wire 2
var wire2cost = 6.09;//How much money is Wire per inch 2? 
var wire3 = 0;//How many inch Wire 3? 
var wire3cost = 6.12;//How much money is Wire 3 per inch? 
var matCost = 16.99;//How much for materials (such as beads or stones)?
var totalPieces = 2;//How many pieces are you making? 
var total1 = (wire1*wire1cost)+(wire2*wire2cost)+(wire3*wire3cost)+matCost;//sum for 1 piece
var totalCost = total1 * totalPieces; //total for all pieces/designs

console.log("Material costs will be"+" "+"$"+totalCost+" "+"to create your"+" "+jewelryName+" "+"design.This is the total for" +" "+ totalPieces+" "+"piece/pieces.");
