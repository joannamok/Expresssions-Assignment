//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Stone Lot Calculator 

var stoneLot = [164] + [86] + [72];

var total = stoneLot[0] + [1] + [2];

console.log(total);