//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 

// Personal - School Lunch Caluculator

// This will determine the total costs for student lunches based on price, amount of students in family and the number of days in the school year.

var numKids = 2;     //How many Kids will be purchasing school lunches? 

var costLunch = 1.75;    //How much is lunch at school? 

var schoolDays = 180; //How many Days in a School Year?

var total = numKids * costLunch * schoolDays; // This is the total cost for the school year.

// This states the total price of school lunches for a family base on the length of the school year and amount of students in household.  
console.log("It will cost"+" "+"$"+total+" "+"for"+" "+numKids+" "+"kid/kids to buy lunches for a full"+" "+schoolDays+" "+"day school year.");
