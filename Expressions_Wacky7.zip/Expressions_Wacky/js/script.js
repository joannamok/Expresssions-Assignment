//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Copper Wire Wrap Jewelry Material Cost Calculator

var name = "earrings"

var wire16 = 16 * .02; //How many inches of 16 gauge wire? 

var wire20 = 4 * .02; //How many inches of 20 gauge wire? 

var wire22 = 0 * .01; //How many inches of 22 gauge wire? 

var wire24 = 22 * .001; //How many inches of 24 gauge wire? 

var earwire = 1 * 1.8; //Add Sterling Earwires? 

var materials = 8.64; //Material Costs such as beads or crystals

var numDesigns = 5; //How many pieces are you making? 

var totalCost = (wire16 + wire20 + wire22 + wire24 + earwire + materials)*numDesigns;

console.log("Your total material cost to make"+" "+numDesigns+" "+"of your copper"+" "+name+" "+"design/designs will be"+" "+"$"+totalCost+".");