//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 

// Stone Lot Calculator 

// This shows a variety of multiple stone lots, customer can choose which lots they would prefer.

var stoneLot = [164] + [86] + [72] + [34] + [23] + [64] + [85]; 	// This is the different stone lots with the amount of stones included listed.

var total = stoneLot[0] + stoneLot[4] + stoneLot[6]; // // Which stone lots would you like? 

// This states the total amount of stones to receive from chosen stone lots.  

console.log("You will receive a total of"+" "+(total)+" "+"stones with your selected lots. ");