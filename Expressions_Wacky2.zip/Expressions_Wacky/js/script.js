///Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 
// Copper Wire Wrap Jewelry Material Cost Calculator

var name = "earrings"

var wire16 = 16 * .02; 

var wire20 = 4 * .02;  

var wire22 = 0 * .01; 

var wire24 = 22 * .001; 

var earwire = 1 * 1.8;  

var materials = 8.64; 

var numDesigns = 5;

var totalCost = (wire16 + wire20 + wire22 + wire24 + earwire + materials)*numDesigns;

console.log("Your total material cost to make"+" "+numDesigns+" "+"of your copper"+" "+name+" "+"design will be"+" "+"$"+totalCost+".");