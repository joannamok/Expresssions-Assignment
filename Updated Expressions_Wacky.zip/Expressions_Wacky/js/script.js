//Joanna Mokhtarezadeh_4-17-13_Expressions Assignment 

// Copper Wire Wrap Jewelry Material Cost Calculator

//The following vars will determine the complete material costs for making a copper jewelry design -prices based on current market price.

var name = "earrings" // What type of jewelry are you making?

var wire16 = 16 * .02; //How many inches of 16 gauge wire? 

var wire20 = 4 * .02; //How many inches of 20 gauge wire? 

var wire22 = 0 * .01; //How many inches of 22 gauge wire? 

var wire24 = 22 * .001; //How many inches of 24 gauge wire? 

var earwire = 1 * 1.8; //Add Sterling Earwires? 

var materials = 8.64; //Material Costs such as beads or crystals

var numDesigns = 5; //How many pieces are you making? 

var totalCost = (wire16 + wire20 + wire22 + wire24 + earwire + materials)*numDesigns; // This is the total cost of all materails,based on number of designs created

// This will determine the total cost of materail needed to make your design, including multiples of the same design.

console.log("Your total material cost to make"+" "+numDesigns+" "+"of your copper"+" "+name+" "+"design will be"+" "+"$"+totalCost+"."); 